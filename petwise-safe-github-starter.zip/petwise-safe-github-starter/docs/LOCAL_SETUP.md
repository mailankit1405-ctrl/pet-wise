# Local setup

## 1. Install prerequisites

- Node.js 20+
- pnpm 9+
- Supabase CLI if you want to run the database locally
- Expo Go on your phone for mobile testing

## 2. Install dependencies

```bash
corepack enable
pnpm install
```

## 3. Add local environment variables

```bash
cp .env.example .env.local
```

Fill in Supabase values locally only. Do not commit `.env.local`.

## 4. Run the project

```bash
pnpm dev
```

Or run one app at a time:

```bash
pnpm dev:web
pnpm dev:api
pnpm dev:mobile
```

## 5. Run Supabase locally

```bash
supabase start
supabase db reset
```

Then copy the local Supabase URL and anon key into `.env.local`.
