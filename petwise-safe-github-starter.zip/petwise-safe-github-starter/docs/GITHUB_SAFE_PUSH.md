# GitHub-safe push checklist

## Before pushing

Run:

```bash
pnpm check:secrets
git status --short
```

Confirm these files are **not** staged:

- `.env`
- `.env.local`
- `.env.production`
- service-role keys
- private signing keys
- real database passwords

## If `.env.local` was already pushed publicly

Deleting the file is not enough because GitHub keeps commit history. Treat every secret in that file as compromised.

1. Rotate/regenerate exposed secrets immediately.
   - Supabase anon key if necessary
   - Supabase service-role key
   - Any API provider keys
2. Remove the file from tracking:

```bash
git rm --cached .env.local
echo ".env.local" >> .gitignore
git add .gitignore
git commit -m "Remove local environment file"
```

3. For a simple personal project, the safest path is often to create a **new clean GitHub repo** and push this starter there.
4. For existing repos, use history cleanup tools only if you understand the force-push impact.

## Fresh clean push

```bash
git init
git add .
git commit -m "Initial safe PetWise starter"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```
