# Deployment guide

## Web app: Vercel

1. Push this repository to GitHub.
2. Import it in Vercel.
3. Set the project root to `apps/web` if Vercel does not auto-detect the monorepo.
4. Add environment variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
5. Build command: `pnpm --filter @petwise/web build`
6. Output: Next.js default.

## API app: Render/Fly/Railway

Deploy `apps/api` as a Node service.

Environment variables:

- `API_PORT`
- `API_HOST`
- `CORS_ORIGIN`
- `NEXT_PUBLIC_SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`

Start command:

```bash
pnpm --filter @petwise/api start
```

Build/typecheck command:

```bash
pnpm install --frozen-lockfile && pnpm --filter @petwise/api build
```

## Supabase

Apply migrations from `supabase/migrations` through the Supabase CLI or SQL editor. Confirm RLS is enabled before storing real user data.

## Mobile

Use Expo Application Services when you are ready:

```bash
pnpm --filter @petwise/mobile start
```

For production builds, configure EAS and app signing credentials. Do not commit signing files.
