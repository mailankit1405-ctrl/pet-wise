# Architecture

## Apps

- `apps/web`: public-facing Next.js app for the community site.
- `apps/api`: Fastify API for server-only logic and future integrations.
- `apps/mobile`: Expo app shell for mobile distribution.

## Packages

- `packages/shared`: shared constants, schemas, and TypeScript types.
- `packages/ui`: small React UI primitives used by the web app.
- `packages/config`: shared TypeScript configs.

## Database

Supabase handles auth and Postgres. The starter schema includes:

- `profiles`
- `pets`
- `posts`
- `provider_listings`

RLS policies are intentionally conservative: authenticated users can read starter data, while users can only manage their own rows.

## Next steps

1. Add Supabase auth screens.
2. Replace demo API data with Supabase queries.
3. Add image uploads through Supabase Storage.
4. Add moderation/reporting flows for community safety.
5. Add provider verification before public launch.
