import type { PetType, PostCategory, ProviderCategory } from "./constants";

export type Profile = {
  id: string;
  displayName: string;
  avatarUrl?: string | null;
  city?: string | null;
  bio?: string | null;
  createdAt: string;
};

export type Pet = {
  id: string;
  ownerId: string;
  name: string;
  type: PetType;
  breed?: string | null;
  ageYears?: number | null;
  photoUrl?: string | null;
  notes?: string | null;
  createdAt: string;
};

export type Post = {
  id: string;
  authorId: string;
  title: string;
  body: string;
  category: PostCategory;
  petId?: string | null;
  createdAt: string;
};

export type ProviderListing = {
  id: string;
  providerId: string;
  businessName: string;
  category: ProviderCategory;
  city: string;
  description?: string | null;
  websiteUrl?: string | null;
  createdAt: string;
};

export type ApiHealth = {
  ok: boolean;
  service: "petwise-api";
  timestamp: string;
};
