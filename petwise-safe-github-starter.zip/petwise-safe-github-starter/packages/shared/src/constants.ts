export const APP_NAME = "PetWise";

export const PET_TYPES = ["dog", "cat", "bird", "rabbit", "reptile", "fish", "other"] as const;
export type PetType = (typeof PET_TYPES)[number];

export const POST_CATEGORIES = ["general", "health", "training", "lost-found", "adoption", "services"] as const;
export type PostCategory = (typeof POST_CATEGORIES)[number];

export const PROVIDER_CATEGORIES = ["vet", "groomer", "walker", "trainer", "sitter", "boarding", "store"] as const;
export type ProviderCategory = (typeof PROVIDER_CATEGORIES)[number];
