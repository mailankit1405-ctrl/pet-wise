import { z } from "zod";
import { PET_TYPES, POST_CATEGORIES, PROVIDER_CATEGORIES } from "./constants";

export const profileSchema = z.object({
  displayName: z.string().min(2).max(80),
  avatarUrl: z.string().url().optional().nullable(),
  city: z.string().max(80).optional().nullable(),
  bio: z.string().max(500).optional().nullable()
});

export const petSchema = z.object({
  name: z.string().min(1).max(80),
  type: z.enum(PET_TYPES),
  breed: z.string().max(80).optional().nullable(),
  ageYears: z.number().int().min(0).max(80).optional().nullable(),
  photoUrl: z.string().url().optional().nullable(),
  notes: z.string().max(1000).optional().nullable()
});

export const postSchema = z.object({
  title: z.string().min(3).max(120),
  body: z.string().min(1).max(5000),
  category: z.enum(POST_CATEGORIES),
  petId: z.string().uuid().optional().nullable()
});

export const providerListingSchema = z.object({
  businessName: z.string().min(2).max(120),
  category: z.enum(PROVIDER_CATEGORIES),
  city: z.string().min(2).max(80),
  description: z.string().max(1000).optional().nullable(),
  websiteUrl: z.string().url().optional().nullable()
});
