# PetWise

PetWise is a safe-to-publish starter monorepo for a social website and mobile shell for animal parents. It includes a Next.js web app, Fastify API, Expo mobile app, shared TypeScript types, reusable UI primitives, and Supabase starter migrations with Row Level Security policies.

## What is included

```txt
apps/
  web/      Next.js web app
  api/      Fastify API server
  mobile/   Expo React Native shell
packages/
  shared/   Shared types, constants, and validation helpers
  ui/       Tiny cross-app UI primitives
  config/   Shared TypeScript configs
supabase/
  migrations/ Starter database schema and RLS policies
docs/       Setup, deployment, and GitHub safety notes
scripts/    Simple secret-safety check
```

## Safe GitHub rule

This repo intentionally includes `.env.example`, but **does not include `.env.local` or real secrets**. Keep it that way.

If you already pushed `.env.local` to GitHub, rotate the keys immediately and read [`docs/GITHUB_SAFE_PUSH.md`](docs/GITHUB_SAFE_PUSH.md).

## Quick start

```bash
corepack enable
pnpm install
cp .env.example .env.local
pnpm dev
```

Then open:

- Web: http://localhost:3000
- API health check: http://localhost:4000/health
- Mobile: run `pnpm dev:mobile` and open with Expo Go

## Useful commands

```bash
pnpm dev          # run web, API, and mobile dev tasks through Turborepo
pnpm dev:web      # web only
pnpm dev:api      # API only
pnpm dev:mobile   # mobile only
pnpm build        # build packages/apps that support build
pnpm typecheck    # TypeScript check
pnpm lint         # lint where configured
pnpm check:secrets
```

## Deployment targets

- Web: Vercel or Netlify
- API: Render, Fly.io, Railway, or a VPS
- Database/Auth: Supabase
- Mobile: Expo Application Services when you are ready for app-store builds

See [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md).
