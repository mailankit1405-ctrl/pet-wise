/** @type {import('next').NextConfig} */
const nextConfig = {
  transpilePackages: ["@petwise/shared", "@petwise/ui"]
};

export default nextConfig;
