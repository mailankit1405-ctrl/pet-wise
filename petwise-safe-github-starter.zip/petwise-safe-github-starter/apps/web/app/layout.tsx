import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PetWise | Social network for animal parents",
  description: "A safe starter app for animal parents to share pets, posts, local services, and care tips."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
