import { Card, Badge } from "@petwise/ui";

const pets = [
  { name: "Milo", type: "Cat", detail: "Tabby · 3 years old" },
  { name: "Luna", type: "Dog", detail: "Husky mix · 5 years old" }
];

export default function PetsPage() {
  return (
    <main className="container">
      <nav className="nav"><a className="logo" href="/">PetWise</a></nav>
      <Badge>Pet profiles</Badge>
      <h1>Your pets</h1>
      <section className="grid">
        {pets.map((pet) => (
          <Card key={pet.name}>
            <h3>{pet.name}</h3>
            <p>{pet.type}</p>
            <p>{pet.detail}</p>
          </Card>
        ))}
      </section>
    </main>
  );
}
