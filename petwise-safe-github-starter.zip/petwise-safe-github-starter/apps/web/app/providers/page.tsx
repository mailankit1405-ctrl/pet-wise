import { Card, Badge } from "@petwise/ui";

const providers = [
  { name: "Neighbourhood Vet", category: "Vet", city: "Vancouver" },
  { name: "Happy Paws Walkers", category: "Walker", city: "Burnaby" },
  { name: "Calm Groom Studio", category: "Groomer", city: "Richmond" }
];

export default function ProvidersPage() {
  return (
    <main className="container">
      <nav className="nav"><a className="logo" href="/">PetWise</a></nav>
      <Badge>Local services</Badge>
      <h1>Provider directory</h1>
      <section className="grid">
        {providers.map((provider) => (
          <Card key={provider.name}>
            <h3>{provider.name}</h3>
            <p>{provider.category}</p>
            <p>{provider.city}</p>
          </Card>
        ))}
      </section>
    </main>
  );
}
