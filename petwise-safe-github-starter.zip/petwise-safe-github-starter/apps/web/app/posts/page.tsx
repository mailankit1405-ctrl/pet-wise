import { Card, Badge } from "@petwise/ui";

const posts = [
  { title: "Best rainy-day walks in Vancouver?", body: "Looking for covered or low-mud routes for a senior dog." },
  { title: "Cat carrier training", body: "What worked for your anxious cat before vet visits?" }
];

export default function PostsPage() {
  return (
    <main className="container">
      <nav className="nav"><a className="logo" href="/">PetWise</a></nav>
      <Badge>Community</Badge>
      <h1>Posts</h1>
      <section className="grid">
        {posts.map((post) => (
          <Card key={post.title}>
            <h3>{post.title}</h3>
            <p>{post.body}</p>
          </Card>
        ))}
      </section>
    </main>
  );
}
