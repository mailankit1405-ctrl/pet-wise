import Link from "next/link";
import { Badge, Card } from "@petwise/ui";
import { APP_NAME } from "@petwise/shared";

const features = [
  { title: "Pet profiles", body: "Create simple profiles for your pets, their routines, notes, and photos." },
  { title: "Community posts", body: "Ask questions, share care tips, and connect with other animal parents." },
  { title: "Local services", body: "Starter provider listings for vets, groomers, walkers, trainers, and sitters." }
];

export default function HomePage() {
  return (
    <main>
      <div className="container">
        <nav className="nav" aria-label="Main navigation">
          <Link className="logo" href="/">{APP_NAME}</Link>
          <div className="nav-links">
            <Link href="/pets">Pets</Link>
            <Link href="/posts">Posts</Link>
            <Link href="/providers">Providers</Link>
          </div>
        </nav>

        <section className="hero">
          <div>
            <Badge>Safe GitHub starter</Badge>
            <h1>A social home for animal parents.</h1>
            <p>
              PetWise gives you a clean foundation for a pet community platform: profiles, posts,
              service listings, Supabase schema, API routes, and a mobile shell without leaked secrets.
            </p>
          </div>

          <aside className="mock-phone" aria-label="PetWise preview">
            <Badge>Community feed</Badge>
            <div className="feed-item"><strong>Milo</strong><br />First vet visit checklist?</div>
            <div className="feed-item"><strong>Luna</strong><br />Looking for rainy-day walk ideas.</div>
            <div className="feed-item"><strong>Vancouver Groomers</strong><br />Provider listings coming soon.</div>
          </aside>
        </section>

        <section className="grid" aria-label="Features">
          {features.map((feature) => (
            <Card key={feature.title}>
              <h3>{feature.title}</h3>
              <p>{feature.body}</p>
            </Card>
          ))}
        </section>
      </div>
      <footer className="footer"><div className="container">Built for safe publishing. Add your own Supabase keys locally only.</div></footer>
    </main>
  );
}
