import type { FastifyInstance } from "fastify";
import { petSchema } from "@petwise/shared";

const demoPets = [
  { id: "demo-1", ownerId: "demo-user", name: "Milo", type: "cat", breed: "Tabby", ageYears: 3, createdAt: new Date().toISOString() },
  { id: "demo-2", ownerId: "demo-user", name: "Luna", type: "dog", breed: "Husky Mix", ageYears: 5, createdAt: new Date().toISOString() }
];

export async function petRoutes(app: FastifyInstance) {
  app.get("/pets", async () => ({ data: demoPets }));

  app.post("/pets", async (request, reply) => {
    const parsed = petSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "Invalid pet payload", details: parsed.error.flatten() });
    }

    return reply.code(201).send({
      data: {
        id: crypto.randomUUID(),
        ownerId: "replace-with-auth-user-id",
        ...parsed.data,
        createdAt: new Date().toISOString()
      }
    });
  });
}
