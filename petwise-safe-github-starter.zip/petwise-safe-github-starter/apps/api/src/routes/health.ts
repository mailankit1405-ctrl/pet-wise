import type { FastifyInstance } from "fastify";
import type { ApiHealth } from "@petwise/shared";

export async function healthRoutes(app: FastifyInstance) {
  app.get("/health", async (): Promise<ApiHealth> => ({
    ok: true,
    service: "petwise-api",
    timestamp: new Date().toISOString()
  }));
}
