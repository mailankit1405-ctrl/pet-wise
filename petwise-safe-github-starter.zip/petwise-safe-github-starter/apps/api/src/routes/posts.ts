import type { FastifyInstance } from "fastify";
import { postSchema } from "@petwise/shared";

const demoPosts = [
  {
    id: "post-demo-1",
    authorId: "demo-user",
    title: "Best rainy-day walks in Vancouver?",
    body: "Looking for covered or low-mud routes for a senior dog.",
    category: "general",
    createdAt: new Date().toISOString()
  }
];

export async function postRoutes(app: FastifyInstance) {
  app.get("/posts", async () => ({ data: demoPosts }));

  app.post("/posts", async (request, reply) => {
    const parsed = postSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: "Invalid post payload", details: parsed.error.flatten() });
    }

    return reply.code(201).send({
      data: { id: crypto.randomUUID(), authorId: "replace-with-auth-user-id", ...parsed.data, createdAt: new Date().toISOString() }
    });
  });
}
