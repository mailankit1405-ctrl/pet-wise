import Fastify from "fastify";
import cors from "@fastify/cors";
import sensible from "@fastify/sensible";
import { env } from "./env";
import { healthRoutes } from "./routes/health";
import { petRoutes } from "./routes/pets";
import { postRoutes } from "./routes/posts";

export async function buildServer() {
  const app = Fastify({ logger: true });

  await app.register(sensible);
  await app.register(cors, { origin: env.CORS_ORIGIN, credentials: true });
  await app.register(healthRoutes);
  await app.register(petRoutes, { prefix: "/api" });
  await app.register(postRoutes, { prefix: "/api" });

  app.get("/", async () => ({ name: "PetWise API", docs: "/health" }));

  return app;
}

const server = await buildServer();

try {
  await server.listen({ port: env.API_PORT, host: env.API_HOST });
} catch (error) {
  server.log.error(error);
  process.exit(1);
}
