import { SafeAreaView, StyleSheet, Text, View } from "react-native";

const pets = ["Milo the cat", "Luna the dog"];

export default function PetsScreen() {
  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.container}>
        <Text style={styles.title}>Demo pets</Text>
        {pets.map((pet) => <Text key={pet} style={styles.card}>{pet}</Text>)}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#fff9f0" },
  container: { padding: 24, gap: 12 },
  title: { fontSize: 34, fontWeight: "900", color: "#23201c", marginBottom: 12 },
  card: { backgroundColor: "white", borderRadius: 18, padding: 18, fontSize: 18, color: "#23201c" }
});
