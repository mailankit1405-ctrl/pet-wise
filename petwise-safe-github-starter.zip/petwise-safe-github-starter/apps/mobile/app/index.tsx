import { APP_NAME } from "@petwise/shared";
import { Link } from "expo-router";
import { SafeAreaView, StyleSheet, Text, View } from "react-native";

export default function HomeScreen() {
  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.container}>
        <Text style={styles.badge}>Safe mobile shell</Text>
        <Text style={styles.title}>{APP_NAME}</Text>
        <Text style={styles.body}>A starter Expo app for animal parents. Connect Supabase auth, pets, posts, and providers as the product grows.</Text>
        <Link href="/pets" style={styles.link}>View demo pets</Link>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#fff9f0" },
  container: { flex: 1, justifyContent: "center", padding: 24, gap: 16 },
  badge: { alignSelf: "flex-start", backgroundColor: "#f4e4ce", paddingHorizontal: 12, paddingVertical: 8, borderRadius: 999, fontWeight: "700", color: "#4f2f18" },
  title: { fontSize: 52, fontWeight: "900", letterSpacing: -3, color: "#23201c" },
  body: { fontSize: 17, lineHeight: 26, color: "#6f675e" },
  link: { marginTop: 12, fontSize: 18, fontWeight: "800", color: "#7a4f2a" }
});
