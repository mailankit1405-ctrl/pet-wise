import { Stack } from "expo-router";

export default function RootLayout() {
  return <Stack screenOptions={{ headerStyle: { backgroundColor: "#fff9f0" }, headerTintColor: "#23201c" }} />;
}
