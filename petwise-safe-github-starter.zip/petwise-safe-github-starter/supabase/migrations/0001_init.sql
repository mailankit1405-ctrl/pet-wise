-- PetWise initial schema.
-- Run this first.

create extension if not exists "pgcrypto";

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 2 and 80),
  avatar_url text,
  city text,
  bio text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists pets (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 80),
  type text not null check (type in ('dog','cat','bird','rabbit','reptile','fish','other')),
  breed text,
  age_years int check (age_years is null or age_years between 0 and 80),
  photo_url text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references profiles(id) on delete cascade,
  pet_id uuid references pets(id) on delete set null,
  title text not null check (char_length(title) between 3 and 120),
  body text not null,
  category text not null default 'general' check (category in ('general','health','training','lost-found','adoption','services')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists provider_listings (
  id uuid primary key default gen_random_uuid(),
  provider_id uuid not null references profiles(id) on delete cascade,
  business_name text not null check (char_length(business_name) between 2 and 120),
  category text not null check (category in ('vet','groomer','walker','trainer','sitter','boarding','store')),
  city text not null,
  description text,
  website_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists pets_owner_id_idx on pets(owner_id);
create index if not exists posts_author_id_idx on posts(author_id);
create index if not exists posts_pet_id_idx on posts(pet_id);
create index if not exists provider_listings_city_idx on provider_listings(city);
create index if not exists provider_listings_category_idx on provider_listings(category);
