-- Enable Row Level Security and starter policies for PetWise.
-- Run after 0001_init.sql.

alter table profiles enable row level security;
alter table pets enable row level security;
alter table posts enable row level security;
alter table provider_listings enable row level security;

-- Profiles: anyone authenticated can read; a user can only edit their own row.
create policy "profiles are viewable by authenticated users"
  on profiles for select
  to authenticated
  using (true);

create policy "users can update their own profile"
  on profiles for update
  to authenticated
  using (auth.uid() = id);

create policy "users can insert their own profile"
  on profiles for insert
  to authenticated
  with check (auth.uid() = id);

-- Pets: owners have full control; everyone authenticated can view.
create policy "pets are viewable by authenticated users"
  on pets for select
  to authenticated
  using (true);

create policy "owners manage their own pets"
  on pets for all
  to authenticated
  using (auth.uid() = owner_id)
  with check (auth.uid() = owner_id);

-- Posts: viewable by everyone authenticated; authors manage their own.
create policy "posts are viewable by authenticated users"
  on posts for select
  to authenticated
  using (true);

create policy "authors manage their own posts"
  on posts for all
  to authenticated
  using (auth.uid() = author_id)
  with check (auth.uid() = author_id);

-- Provider listings: authenticated read, providers manage their own listings.
create policy "listings are viewable by authenticated users"
  on provider_listings for select
  to authenticated
  using (true);

create policy "providers manage their own listings"
  on provider_listings for all
  to authenticated
  using (auth.uid() = provider_id)
  with check (auth.uid() = provider_id);
