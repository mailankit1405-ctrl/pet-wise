# Security Policy

## Secrets

Never commit `.env`, `.env.local`, service-role keys, private API keys, signing keys, or database passwords.

If a secret was committed:

1. Rotate the secret with the provider immediately.
2. Remove the file from the current branch.
3. Rewrite Git history or create a fresh clean repository.
4. Force-push only if you understand the impact on collaborators.

## Reporting issues

Open a private security advisory or contact the repository owner directly for sensitive issues.
