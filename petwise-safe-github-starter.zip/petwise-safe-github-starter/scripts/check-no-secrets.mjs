import { readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";

const root = process.cwd();
const blockedFileNames = new Set([".env", ".env.local", ".env.production", ".env.development"]);
const allowed = new Set([".env.example"]);
const ignoredDirs = new Set(["node_modules", ".git", ".next", "dist", "build", ".turbo", ".expo"]);
const riskyPatterns = [
  /SUPABASE_SERVICE_ROLE_KEY\s*=\s*[^\s#]+/i,
  /sk-[A-Za-z0-9_-]{20,}/,
  /AKIA[0-9A-Z]{16}/,
  /-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----/
];

const failures = [];

function walk(dir) {
  for (const item of readdirSync(dir)) {
    const full = join(dir, item);
    const stat = statSync(full);
    if (stat.isDirectory()) {
      if (!ignoredDirs.has(item)) walk(full);
      continue;
    }
    const rel = full.slice(root.length + 1);
    if (blockedFileNames.has(item) && !allowed.has(item)) {
      failures.push(`Blocked env file found: ${rel}`);
    }
    if (stat.size > 1_000_000) continue;
    if (rel.endsWith(".env.example") || rel.endsWith(".example.json")) continue;
    const text = readFileSync(full, "utf8");
    for (const pattern of riskyPatterns) {
      if (pattern.test(text) && !rel.endsWith("check-no-secrets.mjs")) {
        failures.push(`Possible secret pattern in: ${rel}`);
      }
    }
  }
}

walk(root);

if (failures.length) {
  console.error("Secret safety check failed:\n" + failures.map((f) => `- ${f}`).join("\n"));
  process.exit(1);
}

console.log("No obvious secret files or patterns found.");
